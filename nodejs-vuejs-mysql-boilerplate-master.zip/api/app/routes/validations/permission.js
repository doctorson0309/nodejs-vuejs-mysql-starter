const permissionListGet = require('./permission/listGet');

module.exports = {
  permissionListGet
};
