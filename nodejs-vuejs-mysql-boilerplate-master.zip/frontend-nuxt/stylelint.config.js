module.exports = {
  // add your custom config here
  // https://stylelint.io/user-guide/configuration
  rules: {}
}
