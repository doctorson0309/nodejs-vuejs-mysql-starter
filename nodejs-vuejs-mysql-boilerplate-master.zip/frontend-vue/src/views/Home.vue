<template>
  <b-container class="page-home text-center my-5">
    <img alt="Bootstrap Vue logo" src="../assets/images/bootstrap-vue.png" width="150" />
    <h1>Starter template</h1>
    <p class="lead"
      >Use this document as a way to quickly start any new project.<br />All you get is this text and a mostly barebones
      HTML document.</p
    >
  </b-container>
</template>

<script>
export default {
  name: 'home',
  components: {},
  metaInfo: {
    title: 'Home',
    meta: [
      {
        name: 'description',
        content: 'Welcome to Vue.js frontend.'
      }
    ]
  }
};
</script>
